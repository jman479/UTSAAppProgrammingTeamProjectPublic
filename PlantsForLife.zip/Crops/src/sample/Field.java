package sample;
// Field.java


// What should be in this file:
// Variables: field_name, state, crops
// Methods: New_Field, Exisiting_Field
