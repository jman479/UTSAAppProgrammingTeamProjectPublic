package sample;
// Crops.java


// What should be in this file:
// Variables: crop_name, state, start_date, water_per_week, sunlight
// Methods: Add_Crop_Array, Remove_Crop_Array, Update_Crop_Array
