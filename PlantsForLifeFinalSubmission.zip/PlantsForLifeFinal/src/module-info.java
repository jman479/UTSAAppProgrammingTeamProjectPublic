module PlantsForLifeFinal {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;
    requires javafx.graphics;

    opens Controller;
    opens View;
    opens Model;
}