package Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Scanner;


public class addCropsController {

    private String[] temp;

    private final ArrayList<String> addedCropList = new ArrayList<>();

    private String cropHolder = "";

    @FXML
    private Button viewCropButton;

    @FXML
    private ListView<String> cropsListView;

    private final ObservableList<String> availableCrops = FXCollections.observableArrayList();

    private boolean exists;


    @FXML
    void addButtonPressed(ActionEvent event) {

        if( cropHolder.isEmpty() ){
            try {
                Parent popupOneparent = FXMLLoader.load(getClass().getResource("/View/popupTwo.fxml"));
                Scene popupOneScene = new Scene(popupOneparent);

                Stage popupOnewindow = (Stage) ((Node)event.getSource()).getScene().getWindow();

                popupOnewindow.setScene(popupOneScene);
                popupOnewindow.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Hello World");
        addedCropList.add(cropHolder);
        System.out.println(addedCropList.get(0));

    }

    @FXML
    void doneButtonPressed(ActionEvent event) {

        //need to fix this, when creating a new account there isnt a file to check and see if there are already crops
        //probably needs to be reordered
        String filenameU = "";
        String line = "";
        String user = "";

        try{
            BufferedReader br = new BufferedReader(new FileReader( "src/Model/user_accounts.csv" ));

            while ((line = br.readLine()) != null)
            {
                String[] accounts = line.split(",");

                user = accounts[0];
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try
        {
            File temp;
            temp = File.createTempFile("myTempFile", ".txt");

            this.exists = temp.exists();

            System.out.println("Temp file exists : " + exists);
        } catch (IOException e)
        {
            e.printStackTrace();
        }

        filenameU = "plantsForLife/src/Model/" + user + ".csv";
        System.out.println( filenameU );

        /*try{

            File file = new File( filenameU );
            Scanner scanner = new Scanner( file );
            while( scanner.hasNext() ){
                this.temp = scanner.nextLine().split(",");
            }
            scanner.close();
        }
        catch( FileNotFoundException e){
            e.printStackTrace();
        }*/

        if( addedCropList.isEmpty() && this.exists ){
            try {
                Parent popupOneparent = FXMLLoader.load(getClass().getResource("/View/popupOne.fxml"));
                Scene popupOneScene = new Scene(popupOneparent);

                Stage popupOnewindow = (Stage) ((Node)event.getSource()).getScene().getWindow();

                popupOnewindow.setScene(popupOneScene);
                popupOnewindow.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }

        else{
            /*String filenameU = "";
            String line = "";
            String user = "";

            try{
                BufferedReader br = new BufferedReader(new FileReader( "src/Model/user_accounts.csv" ));

                while ((line = br.readLine()) != null)
                {
                    String[] accounts = line.split(",");

                    user = accounts[0];
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            filenameU = "src/Model/" + user + ".csv";
            System.out.println( filenameU );*/

            try {
                int i = 0;
                while( i < addedCropList.size() ){
                    String temp = "," + addedCropList.get(i);
                    Files.write(Paths.get(filenameU), temp.getBytes(), StandardOpenOption.APPEND);
                    i++;
                }

            }catch (IOException e) {
                e.printStackTrace();
            }

            try {
                Parent fieldOverviewparent = FXMLLoader.load(getClass().getResource("/fieldOverview.fxml"));
                Scene fieldOverviewScene = new Scene(fieldOverviewparent);

                Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();

                window.setScene(fieldOverviewScene);
                window.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    @FXML
    void viewCropButtonPressed(ActionEvent event) {

        if( cropHolder.isEmpty() ){
            try {
                Parent popupOneparent = FXMLLoader.load(getClass().getResource("/View/popupThree.fxml"));
                Scene popupOneScene = new Scene(popupOneparent);

                Stage popupOnewindow = (Stage) ((Node)event.getSource()).getScene().getWindow();

                popupOnewindow.setScene(popupOneScene);
                popupOnewindow.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }

        else{
            try{
                Parent root = FXMLLoader.load(getClass().getResource("/View/" + cropHolder + "Info.fxml"));
                Stage overview = new Stage();
                overview.setTitle("Plants for Life");
                overview.setScene(new Scene(root, 600, 400));

                overview.show();

            } catch (Exception e) {
                e.printStackTrace();
                e.getCause();
            }
        }

    }

    public void initialize(){

        try{

            File cropData = new File( "plantsForLife/src/Model/cropData.csv" );
            Scanner scanner = new Scanner( cropData );
            while( scanner.hasNext() ){
                String[] temp = scanner.nextLine().split(",");
                availableCrops.add(temp[0]);
            }
            scanner.close();
        }
        catch( FileNotFoundException e){
            e.printStackTrace();
        }

        cropsListView.setItems(availableCrops);

        cropsListView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                cropHolder = cropsListView.getSelectionModel().getSelectedItem();
                System.out.println(cropHolder);
            }
        });

    }

}