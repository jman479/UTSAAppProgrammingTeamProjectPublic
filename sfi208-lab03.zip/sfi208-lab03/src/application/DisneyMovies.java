package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

// This class creates movie objects for the disney movies
public class DisneyMovies 
{
	private String DisneyMovies_Name;
	private ArrayList<Movies> movies;
	private ArrayList<Cast> matchResults;
  

	// Constructor that initializes Disney Movies 
	// @param DisneyMovies_Name
	public DisneyMovies(String DisneyMovies_Name)
	{
		this.setDisneyMovies_Name(DisneyMovies_Name);
		this.setMovies(new ArrayList<Movies>());
	}

	// toString method to format the information
	// @return formatted output
	public String toString()
	{
		return this.DisneyMovies_Name + "\"! \n================================\n" + Arrays.deepToString(movies.toArray()).replace(",", "").replace("[", "").replace("]", "").replace("null", "");
}

	// This function loads the movies from the csv file
	// @param fileName
	public void loadMovies(String fileName) throws IOException
	{
		fileName = "data/movies.csv";
		File file = new File(fileName); ///creates a file object
		try 
		{
			Scanner inputStream = new Scanner(file); //opens the file for reading
			while (inputStream.hasNextLine())
			{
				String data = inputStream.nextLine();	
				String[] values = data.split(",");
				String Movie_Name = values[0];
				String Movie_Id = values[1];
				String Movie_genres = values[2];
				Movies movie = new Movies(Movie_Name, Movie_Id, Movie_genres);
				addMovie(movie);
			}
			inputStream.close();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}
  
	// This function reads in the cast information for the movies from a csv file
	//@param fileName location of a file to be read in
	public void loadCast(String fileName) throws IOException 
	{
		fileName = "data/characters.csv";
		File file = new File(fileName); ///creates a file object
		try 
		{
			Scanner inputStream = new Scanner(file); //opens the file for reading
			while (inputStream.hasNextLine())
			{
				String data = inputStream.nextLine();
				String[] values = data.split(",");
				String character_Name = values[0];
				String actor_Name = values[1];
				String character_role = values[2];
				String Movie_Id = values[3];
				String actor_nationality = values[4];
				Cast characters = new Cast(character_Name, actor_Name, character_role, actor_nationality);
				int movieIndex = 0;
				
				//checks for movie name and if it matches inputs into the correct movie
				for (int k = 0; k < movies.size(); k++)
				{
					if(movies.get(k).getMovie_Id().equalsIgnoreCase(Movie_Id))
					{
						movieIndex = k;
						break;
					}
				}
				this.movies.get(movieIndex).addCastInfo(characters);
			}
			inputStream.close();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}
  
	// This function adds movies to the movie list
	// @param movie name
	public void addMovie(Movies new_movie)
	{
		movies.add(new_movie);
	}
  
	// This function removes movies from the list
	public void removeMovie(Movies delete_movie)
	{
		this.movies.remove(delete_movie);
	}
  
	// This function gets and returns the movie name
	// @return movie name
	public String getDisneyMovies_Name() 
	{
		return DisneyMovies_Name;
	}

	// getters and setters
	
	// @param movie name
	public void setDisneyMovies_Name(String disneyMovies_Name) 
	{
		DisneyMovies_Name = disneyMovies_Name;
	}

	// @return movie
	public ArrayList<Movies> getMovies() 
	{
		return movies;
	}

	// @param array of movies
	public void setMovies(ArrayList<Movies> movies)
	{
		this.movies = movies;
	}
  
	// This function gets the movie name that has been input
	// @param movie input
	public ArrayList<Cast> getMoviesByName(String movieInput)
	{
		matchResults = new ArrayList<Cast>();
		
		for (int k = 0; k < movies.size(); k++)
		{
			if (movieInput.matches(movies.get(k).getMovie_Name()))
			{
				matchResults.addAll(movies.get(k).getCharacters());
			}
		}
		return matchResults; 
	}
}
