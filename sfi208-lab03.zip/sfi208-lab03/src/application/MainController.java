package application;
import javafx.event.ActionEvent;
import java.io.IOException;
import application.DisneyMovies;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class MainController 
{
	@FXML
	private TextArea results;
	@FXML
	private Label userPrompt;
	@FXML
	private Button button;
	@FXML
	private TextField userinput;
	@FXML
	void handleButton(ActionEvent event) throws IOException 
	{
		DisneyMovies movies19 = new DisneyMovies("Disney Movies 2019");
		movies19.loadMovies("data/movies.csv");
		movies19.loadCast("data/characters.csv");
	}
	
}
