package application;

import java.util.ArrayList;
import java.util.Arrays;

// This class sets the movie that was input and get the information ready to print

public class Movies 
{  
	private String Movie_Name;
	private String Movie_Id;
	private String Movie_genres;
	private ArrayList<Cast> characters;

	
	// Constructor that initializes Movies with provided attributes
	//@param Movie_Name
	// @param Movie_Id
	// @param Movie_genres
	public Movies(String Movie_Name, String Movie_Id, String Movie_genres)
	{
		this.Movie_Name = Movie_Name;
		this.Movie_Id = Movie_Id;
		this.Movie_genres = Movie_genres;
		this.characters = new ArrayList<Cast>();
	}
  
	// Function adds cast info to the movie
	// @param character
	public void addCastInfo(Cast character)
	{
		characters.add(character);
	}


	// This function removes cast from the movie
	// @param character
	public void removeCast(Cast character)
	{
		for (int i=0; i>characters.size();i++)
		{
			if (character.getCharacter_Name() == character.get(i).getCharacter_Name())
			{
				characters.remove(character);
			}
		}
	}
  
	// toString which formats the movie info
	// @return formatted movie info
	public String toString()
	{
		return Movie_Name + Movie_Id + ", Genre: " + Movie_genres + "Cast: " + getCastSize() + Arrays.toString(characters.toArray());
	}

	// getters and setters

	// @return move name
	public String getMovie_Name() 
	{
		return Movie_Name;
	}

	// @param movie name
	public void setMovie_Name(String movie_Name) 
	{
		Movie_Name = movie_Name;
	}

	// @return movie id
	public String getMovie_Id() 
	{
		return Movie_Id;
	}

	// @param movie id
	public void setMovie_Id(String movie_Id) 
	{
		Movie_Id = movie_Id;
	}

	// @return movie genre
	public String getMovie_genres() 
	{
		return Movie_genres;
	}

	// @param movie genres
	public void setMovie_genres(String movie_genres) 
	{
		Movie_genres = movie_genres;
	}

	// @return characters
	public ArrayList<Cast> getCharacters() 
	{
		return characters;
	}

	// @param characters
	public void setCharacters(ArrayList<Cast> characters)
	{
		this.characters = characters;
	}
  
	// This function returns the array size of cast members
	// @return cast array size2
	public int getCastSize()
	{
		return characters.size();
	}
  
	// This function returns the character is a specified array position
	// @return character
	public Cast getcharacter(int i)
	{
		return characters.get(i);
	}
}