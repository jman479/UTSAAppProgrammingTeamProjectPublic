package application;

// This class will get the cast members for the movie selected and format it to print
public class Cast 
{
	private String character_Name;
	private String actor_Name;
	private String character_role;
	private String actor_nationality;
  

	// Constructor that initializes Cast
	// @param character_Name - name of character
	// @param actor_Name - name of actor
	// @param character_role - name of role
	// @param actor_nationality - actor nationality
	public Cast (String character_Name, String actor_Name, String character_role, String actor_nationality)
	{
		this.character_Name = character_Name;
		this.actor_Name = actor_Name;
		this.character_role = character_role;
		this.actor_nationality = actor_nationality;
  
	}
  
	public Cast()
	{
		character_Name= "";
		actor_Name = "";
		character_role = "";
		actor_nationality= "";
	}
  
	// toString that formats the output
	// @return formatted string
	public String toString()
	{
		return String.format(" - %s %s %s (%s)\n", character_role, character_Name, actor_Name, actor_nationality);
	}
  
	// getters and setters
	
	// @return character name 
	public String getCharacter_Name() 
	{
		return character_Name;
	}
	
	// @param character name
	public void setCharacter_Name(String character_Name) 
	{
		this.character_Name = character_Name;
	}
	
	// @return actor name
	String getActor_Name() 
	{
		return actor_Name;
	}

	// @param actor name
	public void setActor_Name(String actor_Name) 
	{
		this.actor_Name = actor_Name;
	}
	
	// @return character role
	public String getCharacter_role() 
	{
		return character_role;
	}

	// @param character role
	public void setCharacter_role(String character_role) 
	{
		this.character_role = character_role;
	}

	// @return actor nationality
	public String getActor_nationality() 
	{
		return actor_nationality;
	}

	// @param actor nationality
	public void setActor_nationality(String actor_nationality) 
	{
		this.actor_nationality = actor_nationality;
	}

	public Cast get(int i) 
	{
		return null;
	}
}