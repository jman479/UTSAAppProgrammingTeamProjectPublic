module PFLWork {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;

    opens Controller;
    opens View;
    opens Model;
}