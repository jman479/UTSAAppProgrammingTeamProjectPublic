package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class FOpopupController {

    @FXML
    private Label message;

    @FXML
    private Button closeButton;

    @FXML
    void closeButonPressed(ActionEvent event) {

        try {
            Parent fieldOverviewparent = FXMLLoader.load(getClass().getResource("/View/fieldOverview.fxml"));
            Scene fieldOverviewScene = new Scene(fieldOverviewparent);

            Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();

            window.setScene(fieldOverviewScene);
            window.show();
        }

        catch (IOException e) {
            e.printStackTrace();
        }

    }

}