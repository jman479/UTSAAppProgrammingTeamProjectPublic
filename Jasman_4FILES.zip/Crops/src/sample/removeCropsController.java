package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;


public class removeCropsController {

    private final ArrayList<String> addedCropList = new ArrayList<String>();

    private String cropHolder = "";


    @FXML
    private ListView<String> cropsListView;

    private final ObservableList<String> availableCrops = FXCollections.observableArrayList();



    @FXML
    void doneButtonPressed(ActionEvent event) {

            try {
                Parent fieldOverviewparent = FXMLLoader.load(getClass().getResource("/sample/fieldOverview.fxml"));
                Scene fieldOverviewScene = new Scene(fieldOverviewparent);

                Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();

                window.setScene(fieldOverviewScene);
                window.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }

    }



