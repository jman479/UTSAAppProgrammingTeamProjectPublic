package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class fieldOverviewController {


    @FXML
    private Button exitB;
    
    @FXML
    private Button addCropButton;
    
    @FXML
    private Button removeCropButton;
	
	/**
     * exitButtonAction will cause the window to close if the user
     * presses the exit button.
     * @param event - mouse click
     */
    public void exitButtonAction(ActionEvent event)
    {
        Stage stage = (Stage) exitB.getScene().getWindow();
        stage.close();
    }
    
    // When this method is called, it will change the scene to the Add Crops page
    
    public void addCropsButtonPushed(ActionEvent event)
    {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("addCrops.fxml"));
			Stage addCrops = new Stage();
	        addCrops.setTitle("Plants for Life");
	        addCrops.setScene(new Scene(root, 600, 400));
	        addCrops.show();
			
			} catch (IOException e) {
			e.printStackTrace();
			e.getCause();
		}
    	
    }
    
 // When this method is called, it will change the scene to the Remove Crops page
    
    public void removeCropsButtonPushed(ActionEvent event)
    {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("removeCrops.fxml"));
			Stage addCrops = new Stage();
	        addCrops.setTitle("Plants for Life");
	        addCrops.setScene(new Scene(root, 600, 400));
	        addCrops.show();
			
			} catch (IOException e) {
			e.printStackTrace();
			e.getCause();
		}
    	
    }
    
    
    public void fieldOverviewPage()
    {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("fieldOverview.fxml"));
            Stage overview = new Stage();
            overview.setTitle("Plants for Life");
            overview.setScene(new Scene(root, 600, 600));
            overview.show();

        } catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }
    }
}
