import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;


public class addCropsController {

    private final ArrayList<String> addedCropList = new ArrayList<String>();

    private String cropHolder = "";

    private Button viewCropButton;

    @FXML
    private ListView<String> cropsListView;

    private final ObservableList<String> availableCrops = FXCollections.observableArrayList();

    public addCropsController() {
    }

    @FXML
    void addButtonPressed(ActionEvent event) {

        if( cropHolder.isEmpty() ){
            try {
                Parent popupOneparent = FXMLLoader.load(getClass().getResource("/sample/popupTwo.fxml"));
                Scene popupOneScene = new Scene(popupOneparent);

                Stage popupOnewindow = (Stage) ((Node)event.getSource()).getScene().getWindow();

                popupOnewindow.setScene(popupOneScene);
                popupOnewindow.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Hello World");
        addedCropList.add(cropHolder);
        System.out.println(addedCropList.get(0));

    }

    @FXML
    void doneButtonPressed(ActionEvent event) {

        if( addedCropList.isEmpty() ){
            try {
                Parent popupOneparent = FXMLLoader.load(getClass().getResource("/sample/popupOne.fxml"));
                Scene popupOneScene = new Scene(popupOneparent);

                Stage popupOnewindow = (Stage) ((Node)event.getSource()).getScene().getWindow();

                popupOnewindow.setScene(popupOneScene);
                popupOnewindow.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }

        else{
            String filenameU = "";
            String line = "";
            String user = "";

            try{
                BufferedReader br = new BufferedReader(new FileReader( "src/sample/user_accounts.csv" ));

                while ((line = br.readLine()) != null)
                {
                    String[] accounts = line.split(",");

                    user = accounts[0];
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            filenameU = "src/sample/" + user + ".csv";
            System.out.println( filenameU );

            /*try {
                FileWriter cropWriter = new FileWriter(filenameU, true);
                int i = 0;
                while( i < addedCropList.size() ){
                    cropWriter.append(", ").append(addedCropList.get(i));
                    i++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }*/

            try {
                int i = 0;
                while( i < addedCropList.size() ){
                    String temp = "," + addedCropList.get(0);
                    Files.write(Paths.get(filenameU), temp.getBytes(), StandardOpenOption.APPEND);
                    i++;
                }

            }catch (IOException e) {
                e.printStackTrace();
                //exception handling left as an exercise for the reader
            }

            try {
                Parent fieldOverviewparent = FXMLLoader.load(getClass().getResource("/sample/fieldOverview.fxml"));
                Scene fieldOverviewScene = new Scene(fieldOverviewparent);

                Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();

                window.setScene(fieldOverviewScene);
                window.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    @FXML
    void viewCropButtonPressed(ActionEvent event) {

        try{
            //FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/" + cropHolder + "Info.fxml"));
            Parent root = FXMLLoader.load(getClass().getResource("/sample/" + cropHolder + "Info.fxml"));
            Stage overview = new Stage();
            overview.setTitle("Plants for Life");
            overview.setScene(new Scene(root, 600, 400));

            //cropInfoController controller = new cropInfoController();
            //someNode.setUserData(userKey, userData, handler);
            //root.setUserData( 'key', cropHolder, null );
            //controller.initialize( cropHolder );

            overview.show();

        } catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }/*
        //opens selected crops information page w/ back button to come back to addCrops screen
        //NEED TO FIGURE OUT HOW TO PASS INFO FROM SCENE TO SCENE SO CAN PASS WHAT CROP DATA TO PULL AND POPULATE WITH
       /* if( addedCropList.isEmpty() ){
            try {
                Parent popupOneparent = FXMLLoader.load(getClass().getResource("/sample/popupOne.fxml"));
                Scene popupOneScene = new Scene(popupOneparent);

                Stage popupOnewindow = (Stage) ((Node)event.getSource()).getScene().getWindow();

                popupOnewindow.setScene(popupOneScene);
                popupOnewindow.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }
        else{
            try {
                Parent cropInfoparent = FXMLLoader.load(getClass().getResource("/sample/cropInfo.fxml"));
                Scene cropInfoScene = new Scene(cropInfoparent);

                Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();

                window.setScene(cropInfoScene);
                window.show();
            }

            catch (IOException e) {
                e.printStackTrace();
            }
        }*/

    }

    public void initialize(){

        try{

            File cropData = new File( "src/sample/cropData.csv" );
            Scanner scanner = new Scanner( cropData );
            while( scanner.hasNext() ){
                String[] temp = scanner.nextLine().split(",");
                availableCrops.add(temp[0]);
            }
            scanner.close();
        }
        catch( FileNotFoundException e){
            e.printStackTrace();
        }

        cropsListView.setItems(availableCrops);

        cropsListView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                cropHolder = cropsListView.getSelectionModel().getSelectedItem();
                System.out.println(cropHolder);
            }
        });


    }

}


