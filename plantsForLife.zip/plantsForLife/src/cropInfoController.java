import javafx.collections.transformation.TransformationList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class cropInfoController implements Initializable{

    @FXML
    private ImageView cropImage = new ImageView();

    @FXML
    private Label cropName;

    @FXML
    private Label cropDaysToHarvest;

    @FXML
    private Label cropWaterNeeded;

    @FXML
    private Label cropCurrentPrice;
    private Object Node;

    @FXML
    void backButtonPressed(ActionEvent event) {

        try {
            Parent addCropsparent = FXMLLoader.load(getClass().getResource("/sample/addCrops.fxml"));
            Scene addCropsScene = new Scene(addCropsparent);

            Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();

            window.setScene(addCropsScene);
            window.show();
        }

        catch (IOException e) {
            e.printStackTrace();
        }

    }

    /*
    @FXML
    public void initialize( String cropHolder ) {

        System.out.println( cropHolder );
        cropName.setText( cropHolder );

        //File file = new File("Ears-corn.jpeg");
        //Image image = new Image("file:/Users/hlong/intelliJ-workspace/plantsForLife/src/sample/Ears-corn.png");
        //cropImage.setImage( image );

        //File file = new File("src/Box13.jpg");
        //Image image = new Image(file.toURI().toString());
        //imageView.setImage(image);


    }*/


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        System.out.println(cropName.getUserData());

        //cropName.setText(String.valueOf(cropName));

    }

}
