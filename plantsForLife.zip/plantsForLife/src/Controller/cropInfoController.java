package Controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class cropInfoController {

    @FXML
    private ImageView cropImage;

    @FXML
    private Label cropName;

    @FXML
    private Label recommendedFertalizer;

    @FXML
    private Label timeToHarvest;

    @FXML
    private Label irrigationSchedule;

    @FXML
    private Label plantingSeason;

    @FXML
    private Button backButton;

    @FXML
    void backButtonPressed() {

        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();

    }

}