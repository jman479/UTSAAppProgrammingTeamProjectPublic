/*
 * Zoo.java represents the Zoo class for Lab 1
 * In this lab assignment, we use these classes to help manage a zoo
 * 
 * @author Jasman Sidhu (tqx609)
 * UTSA CS 3443.002 - Lab 1
 * Spring 2021
 */
public class Zoo { //This class will represent a Zoo object

private String name; //A name represented as a String
private Zone[] zones; //Zones stored as an array of Zone objects (i.e. Zone[])
private int num; //counter
	
public String getName() { //Getter for name
	return name;
}
	
public void setName(String name) { //Setter for name, parameter of String name
	this.name = name;
}
	
public Zone[] getZones() { //Getter for zones
	return zones;
}
	
public void setZones(Zone[] zones) { //Setter for zones, parameter of Zone[] zones
	this.zones = zones;
}

public Zoo(String name, int max) { //Zoo Constructor, paramater of String name and int max(max amounts)
	this.name = name;
	this.zones = new Zone[max]; 
}
	
	
public void addZone(Zone zone) { //METHOD which takes as a parameter a zone object and returns nothing.
if(num < zones.length) {
	zones[num] = zone;
	num++;	
}
}

//A toString() method, which calls upon the toString() method in Zone.java 
//to return as a String all needed information.
public String toString() {
	
int i; //initialization of i for my for-loop
String str = ""; //Empty String
str += String.format("Welcome to the %s\"! %n------------------------------------%n", getName()); //Welcome Message plus dashes
		
for(i=0; i < num; i++) {
	str += zones[i].toString();
	str += "\n";
}
return str; //Return as a String
}
		
}
