/*
 * Zone.java represents the Zone class for Lab 1
 * In this lab assignment, we use these classes to help manage a zoo
 * 
 * @author Jasman Sidhu (tqx609)
 * UTSA CS 3443.002 - Lab 1
 * Spring 2021
 */

public class Zone { //This class will represent a Zone object
	
private String name; //A name, represented as a String (i.e.: Tiger Zone)
private Animal[] animals; //An array of Animal objects.
private int num;
	
public String getName() { //Getter for name

	return name;
}

public void setName(String name) { //Setter for name, paramter of String name

	this.name = name;
}

public Animal[] getAnimal() { //Getter for animals

	return animals;
}
	
public void setAnimal(Animal[] animals) { //Setter for animals, paramter of Animal[] animals

	this.animals = animals;
}

public Zone(String name, int max) { //Zone Constructor, paramter of String name and int max(max amounts)

	this.name = name;
	this.animals = new Animal[max];
}
	
public void addAnimal(Animal animal) { //An addAnimal(..) method, which takes as a parameter an Animal object and returns nothing.

animals[num] = animal;
num++;
}

public String toString() { //A toString() method which returns a String representation of all animals in the zone

int i;
String str = this.name+" Zone : \n------------------------------------\n";
		
for(i=0; i < num; i++) {
	str += animals[i].toString();
}
return str;
}
	
}
