/*
 * Animal.java represents the Animal class for Lab 1
 * In this lab assignment, we use these classes to help manage a zoo
 * 
 * @author Jasman Sidhu (tqx609)
 * UTSA CS 3443.002 - Lab 1
 * Spring 2021
 */

public class Animal { //This class will represent an Animal object
	
//Variables have to be PRIVATE(constricted to this class)
	
private String name; //A name, represented as a String (i.e. Tiger)
private String type; //A type, represented as a String (i.e. Tiger)
private Boolean eat; //Whether or not the animal is Carnivorous. This will be represented as a boolean (i.e. true, for Tiger)	

public String getName() { //Getter for name

	return name;
}

public void setName(String name) { //Setter for name, paramter of String name

	this.name = name;
}

public String getType() { //Getter for type

	return type;
}

public void setType(String type) { //Setter for type, parameter of String type

	this.type = type;
}
	
public Boolean getEat() { //Getter for eat

	return eat;
}
	
public void setEat(Boolean eat) { //Setter for eat, parameter of Boolean eat

	this.eat = eat;
}
	
public Animal(String name, String type, boolean eat ) { //Animal Constructor - parameter of name, type, and eat

	this.name = name;
	this.type = type;
	this.eat = eat;
}

public String toString() { //A toString() method which returns a String representation of the animal object.

	String s = null;
	
	if(eat == true) { //Whether animal is a meat eater or vegetarian
		s = "Carnivore"; //If true then it's a meat eater
	}else {
		s = "Vegeterian"; //If false then the animal is vegetarian
	}

return String.format(">> %s - %s (%s)\n", name, type, s);	//Animal Description
}


}
